<?php if (@$bzpkod<>1934572) exit("Neoprávnený prístup!!!");  // Bezpečnostný kód
chyba("Chyba nenájdený súbor: $not_file_found","<div align=center style=\"font: bold 20px cursive;\">Chyba !</div><p>
          <div align=center>Žiaľ sa požadovaný článok alebo časť nenašla!<br />
		  Možno došlo k chybe, alebo nemáte dostatočné oprávnenie na prezeranie daného článku!<br />
		  Skúste prosím neskôr...<p>&nbsp;Ak sa to bude opakovať dajte nám prosím vedieť!
		  <p><br /></div>"); 
?>