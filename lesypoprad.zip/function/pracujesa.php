<?php if (@$bzpkod<>1934572) exit("Neoprávnený prístup!!!");  // Bezpečnostný kód
stav_dobre("<div align=center style=\"font: bold 20px cursive;\">Na stránke sa pracuje!</div><p>
          <div align=center>Žiaľ požadovaný článok alebo časť ešte neexistuje!<br />
		  Na tejto časti ale pracujeme, takže prosíme o strpenie.<br />
		  Skúste prosím neskôr...<p></div>"); 
?>